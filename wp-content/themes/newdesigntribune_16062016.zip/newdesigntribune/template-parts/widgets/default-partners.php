<?php
	$template_url	= get_bloginfo('template_url', 'display');
?>

<div class="partners">
	<a target="_blank" href="<?php echo $home_url;?>/subscribe/"><img width="305" height="55" alt="" src="<?php echo $template_url; ?>/img/partners/iht-banner.jpg" /></a>
	<img width="305" height="55" alt="" src="<?php echo $template_url; ?>/img/partners/tcf-banner.jpg" />
</div>

