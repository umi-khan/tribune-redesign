<?php
 $parties = array(
     'anp', 'mqm', 'ppp', 'pti', 'pml(n)', 'pml(q)', 'jui(f)', 'jui(s)','ji'
 )
?>

<div class="political-parties-position widget">
	<h4>PARTY POSITIONS</h4>			
   <div id="chart_div" class="content clearfix"></div>   
</div>   