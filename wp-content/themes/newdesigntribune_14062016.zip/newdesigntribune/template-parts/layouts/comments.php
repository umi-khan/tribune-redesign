<?php
if (__FILE__ == $_SERVER['SCRIPT_FILENAME']) { die(); }

global $post, $wp_query;

if( have_comments() || 'open' == $post->comment_status ) :

	$comment_count = 0;

	if( empty( $post->post_password ) || $_COOKIE['wp-postpass_' . COOKIEHASH] == $post->post_password )			
		$comment_count  = $post->comment_count;	
?>

<?php
	if ( count( $wp_query->comments ) > 0) : ?>
	<div class="last">
		<h2>Reader Comments <?php if ($comment_count > 0) echo "($comment_count)"; ?></h2>
	</div>


	<div class="comments-tabs tabs-container">
		<ul class="tabs ul-tabs clearfix">
			<li>
				<a class="current all-comments" href="#comments">All Comments</a>
			</li>
			<li>
				<a class="recommended-comments" href="#comments">Reader's Recommendations</a>
			</li>
		</ul>

		<div class="tabs-content-group">
			<ul class="commentlist hfeed">
				<?php wp_list_comments('type=comment&callback=exp_threaded_comment'); ?>
			</ul>
			<div class="more-comments">
				<a href="#comments"> MORE </a>
			</div>
			
			<?php if( $comment_count > 150 ) : ?>
			<div class="comment-pagination hide-pagination">
				<?php paginate_comments_links(array('prev_text'=>'&laquo; Older Comments', 'next_text'=>'Newer Comments &raquo;'));?>
			</div>
			<?php endif; ?>
		</div>
	</div>
<?php
	endif;


	exp_template_file('comment-form');
	exp_insert_script('comments');
endif;
?>
