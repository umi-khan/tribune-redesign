<?php

// video category page link related
$video_cat_id   = get_category_by_slug( 'videos' )->cat_ID;
$video_cat_link = get_category_link( $video_cat_id );

// fetch the latest videos
$videos = VM_manager::get_latest_by_category( 0, 0, $num_videos );

?>

<h3>
	<a class="multimedia" href="<?php print $video_cat_link; ?>">Latest Videos</a>
</h3>

<div class="carousel-pagination"></div>

<div class="content">	

	<div class="carousel clear">
		<div class="items clearfix">
			<?php
			
				for( $i = 0, $num_videos = count( $videos ); $i < $num_videos; $i++ ) :
					$video = $videos[$i];
					$link  = $video_cat_link . $video->id . '/';
					$title = esc_html( $video->title );
					$class = '';

					if( $i == 0 )               $class = 'first';
					elseif( $i == $num_videos ) $class = 'last';
				
			?>
			<div class="item <?php echo $class;?>">
				<a class="image" href="<?php echo $link;?>" title="<?php echo $title; ?>">
					<img alt="" src="<?php echo $video->thumbnail->url ;?>"
						  width="134" height="100"/>
				</a>
				
				<p><a href="<?php echo $link;?>"><?php echo $title; ?></a></p>
			</div>
			<?php endfor; ?>
		</div>
	</div>
</div>