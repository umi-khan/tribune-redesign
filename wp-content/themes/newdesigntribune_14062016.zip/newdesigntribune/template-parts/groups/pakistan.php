<?php $pakistan_cat = get_category_by_slug( 'pakistan' ); ?>

<h3 class="m-group">
	<a href="<?php echo get_category_link( $pakistan_cat->cat_ID ); ?>"><?php echo $pakistan_cat->cat_name; ?></a>
</h3>

<div class="last clearfix provinces">
	<?php
		$long_story_args = array( 'show_excerpt' => true, 'is_first' => true );

		$pakistan_subcats = get_categories( array( 'parent' => $pakistan_cat->cat_ID, 'orderby' => 'id' , 'number' => 4 ) );
		for( $i = 0, $j = count( $pakistan_subcats ); $i < $j; $i++ ) :
			$sub_category   = $pakistan_subcats[$i];
			$sub_cat_layout = new LM_layout( $sub_category->cat_ID, LM_config::GROUP_MAIN_STORIES, true, 3 );
	?>
	<div class="col-lg-3 province <?php if( $i == 0 ) echo "first"; ?> <?php if( $i == $j - 1 ) echo "last"; ?>">
		<h4><a href="<?php echo get_category_link( $sub_category->cat_ID ); ?>"><?php echo $sub_category->name; ?></a></h4>

		<?php
			$story = new Control_long_story( array_shift( $sub_cat_layout->posts_stack ), true );
			$story->display( $long_story_args );
		?>
	</div>
	<?php endfor; ?>
</div>