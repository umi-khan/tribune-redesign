<?php

$sports_cat    = get_category_by_slug( 'sports' );
$sports_layout = new LM_layout( $sports_cat->cat_ID, LM_config::GROUP_MAIN_STORIES, true, 7 );

$sports_cat_link = get_category_link( $sports_cat->cat_ID );

?>

<h3 class="m-group">
	<a href="<?php echo $sports_cat_link; ?>"><?php echo $sports_cat->cat_name; ?></a>
</h3>

<div class="col-lg-6 first">
	<?php
	$top_story = new Control_top_story( array_shift( $sports_layout->posts_stack ) );
	$top_story->display( array( 'is_first' => true, 'is_last' => true, 'mob_story'=>true, 'style_bottom'=>true ) );
	?>

	<div class="featured">
		<h4><a href="<?php echo $sports_cat_link; ?>">Featured</a></h4>

		<?php $sports_featured_layout  = new LM_layout( $sports_cat->cat_ID, LM_config::GROUP_FEATURED_STORIES, true, 2 ); ?>
		<div class="clearfix">
			<?php for( $i = 0; $i < 2; $i++ ) : ?>
			<div class="col-lg-6 <?php if( $i == 2 - 1 ){ echo "last";}else{echo "first";} ?>">
				<?php
				$story = new Control_small_picture_story( $sports_featured_layout->posts_stack[$i], $sports_cat );
				$story->display();
				?>
			</div>
			<?php endfor; ?>
		</div>
	</div>
</div>

<div class="col-lg-6 last">
	<?php
	$small_story_args = array();
	for( $i = 0; $i < 5; $i++ )
	{
		$small_story_args['is_first'] = ( $i == 0  ? true : false );
		$small_story_args['is_last']  = ( $i == 5 - 1  ? true : false );

		$story = new Control_small_story( array_shift( $sports_layout->posts_stack ) );
		$story->display( $small_story_args );
	}
	?>
</div>