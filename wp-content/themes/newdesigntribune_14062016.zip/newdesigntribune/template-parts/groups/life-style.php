<?php

$lifestyle_cat    = get_category_by_slug( 'life-style' );
$lifestyle_layout = new LM_layout( $lifestyle_cat->cat_ID, LM_config::GROUP_MAIN_STORIES, true, 5 );

?>

<h3 class="m-group">
	<a href="<?php echo get_category_link( $lifestyle_cat->cat_ID ); ?>"><?php echo $lifestyle_cat->cat_name; ?></a>
</h3>

<div class="clearfix">
	<div class="col-lg-6 first">
		<?php
		$story = new Control_top_story( array_shift( $lifestyle_layout->posts_stack ) );
		$story->display( array( 'is_first' => true, 'mob_story'=> true, 'style_bottom'=>true  ) );

		$story = new Control_story( array_shift( $lifestyle_layout->posts_stack ) );
		$story->display( array( 'is_last' => true, 'show_related' => true ) );
		// Hidden for mobile
		$story = new Control_story( array_shift( $lifestyle_layout->posts_stack ) );
		$story->display( array( 'is_last' => true, 'show_related' => true , 'hidden'=>true ) );

		$story = new Control_story( array_shift( $lifestyle_layout->posts_stack ) );
		$story->display( array( 'is_last' => true, 'show_related' => true , 'hidden'=>true ) );

		$story = new Control_story( array_shift( $lifestyle_layout->posts_stack ) );
		$story->display( array( 'is_last' => true, 'show_related' => true , 'hidden'=>true ) );
		?>	
	</div>
	
	<div class="group-small-picture-stories col-lg-6 last">
	
		<?php
			$subcategory_mappings = array( 
				'gossip' => 'gossip',
				'tv-film' => 'review',
				'fashion' => 'advice',
				'life-style' => 'oddity'
			);

			$counter = 0;
			foreach($subcategory_mappings as $subcategory_slug => $mapping ) :
				$subcategory        = get_category_by_slug( $subcategory_slug );
				$subcategory->name  = $mapping;

				$subcategory_layout = new LM_layout( $subcategory->cat_ID, LM_config::GROUP_FEATURED_STORIES, true, 1 );
				$sub_cat_story      = new Control_small_picture_story( array_shift( $subcategory_layout->posts_stack ),
						  $subcategory, true, false, true );
				
				$current_class = ( $counter % 2 ) ? ' last' : ' first';

				$counter++;
		?>
			<div class="col-lg-6 <?php echo $current_class; ?>">
				<?php $sub_cat_story->display(); ?>
			</div>
		<?php endforeach; ?>
	</div>
</div>

<div class="small-slideshows">
	<h4>Slideshows</h4>
	<div class="content clearfix">
		<?php
			$slideshows = SS_manager::get_latest( $lifestyle_cat->cat_ID, 0, 4 );
			
			$slideshows_cat      = get_category_by_slug( 'slideshows' );
			$slideshows_cat_link = get_category_link( $slideshows_cat->cat_ID );
			
			foreach($slideshows as $key => $slideshow) :
			
				$link      = trailingslashit( $slideshows_cat_link . $slideshow->id );
				$title     = esc_html( $slideshow->title );
				$thumbnail = $slideshow->default_image->thumbnail;
	
				$class = '';
				if( $key == 0 )         $class = 'first';
				elseif( $key == 4 - 1 ) $class = 'last';
	
		?>
			<div class="small-slideshow col-lg-3 <?php echo $class; ?>">
				<a class="image" href="<?php echo $link;?>" title="<?php echo $title; ?>">
					<img alt="" src="<?php echo $thumbnail->url ;?>" />
				</a>
				<p><a href="<?php echo $link;?>"><?php echo $title; ?></a></p>
			</div>
		<?php endforeach;?>
	</div>
</div>