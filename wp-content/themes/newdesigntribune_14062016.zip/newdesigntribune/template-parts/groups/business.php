<?php

$num_long_stories = 4;

$business_cat    = get_category_by_slug( 'business' );
$business_layout = new LM_layout( $business_cat->cat_ID, LM_config::GROUP_MAIN_STORIES, true, 9 );

$business_cat_link = get_category_link( $business_cat->cat_ID );

?>

<h3 class="m-group">
	<a href="<?php echo $business_cat_link; ?>"><?php echo $business_cat->cat_name; ?></a>
</h3>

<div class="col-lg-6 first">
	<?php
	$top_story = new Control_top_story( array_shift( $business_layout->posts_stack ) );
	$top_story->display( array( 'is_first' => true, 'is_last' => true , 'mob_story'=> true, 'style_bottom'=>true ) );
	?>
</div>

<div class="col-lg-6 market last">	
	<?php
	$small_story_args = array();
	for( $i = 0; $i < 4; $i++ )
	{
		$small_story_args['is_first'] = $i == 0;
		$small_story_args['is_last']  = $i == 4 - 1;

		$story = new Control_small_story( array_shift( $business_layout->posts_stack ) );
		$story->display( $small_story_args );
	}
	?>
</div>

<div class="col-lg-12 first analysis">
	<h4><a href="<?php echo $business_cat_link; ?>">NEWS &amp; ANALYSIS</a></h4>
	<div class="clearfix">
		<?php
		$args = array( 'is_first' => false, 'is_last' => false );
		for( $i = 0; $i < 4; $i++ ) :
			if( $i == 0 ) $args['is_first'] = true;
			if( $i == 3 ) $args['is_last']  = true;
		?>
		<div class="col-lg-3 <?php if( $i == 4 - 1 ){ echo "last";}elseif( $i == 0 ){echo "first";} ?>">
			<?php
			$story = new Control_long_story( array_shift( $business_layout->posts_stack ) );
			$story->display( $args );
			?>
		</div>
		<?php endfor; ?>
	</div>
</div>