<?php /* Template Name: Home1 */

// current category
$category_id = 0;

$layout = new LM_layout( $category_id, LM_config::GROUP_MAIN_STORIES );

?>

<?php get_header();  ?>
       			
 

<div class="home">
<div class="col-lg-8">
<?php
        $main_story = new Control_main_story( array_shift( $layout->template_stories[LM_config::TEMPLATE_SUB_STORY] ) );
        $main_story->display( array( 'is_first' => true, 'mob_story'=> true ) );

        $args = array( 'is_first' => false, 'is_last' => false );
       // for( $i = 0, $j = count( $layout->template_stories[LM_config::TEMPLATE_SUB_STORY] ); $i < $j; $i++ )
        for( $i = 0, $j = 3; $i < $j; $i++ )
        {
          if( $i == $j - 1 ) $args['is_last'] = true;
          $sub_story = new Control_story( $layout->template_stories[LM_config::TEMPLATE_SUB_STORY][$i] );
          $sub_story->display( $args );
        }
      ?>


        <?php
        /*foreach( $layout->template_stories[LM_config::TEMPLATE_TOP_STORY] as $pic_story )
        {
          $pic_story = new Control_picture_story( $pic_story );
          $pic_story->display();
        }*/
      ?>
        
        <?php
        $featured_layout = new LM_layout( (int)$category_id, LM_config::GROUP_FEATURED_STORIES );
        $args = array( 'is_first' => false, 'is_last' => false, 'is_end'=>false, 'is_mid' => false);
        for( $i = 0, $j = 5; $i < $j; $i++ ) {
        //for( $i = 0, $j = ((count( $featured_layout->posts_stack )) <= 10 )? count( $featured_layout->posts_stack ) : 10 ; $i < $j; $i++ ) {
          $args['is_first'] = ( $i == 0 ) ? true : false;
          // $args['is_last']  = ( $i == $j - 1 ) ? true : false;
          $args['is_mid']  = ($i == 5 || $i ==0 ) ?  true : false;
          
          if ($i > 4 ){
            $args['is_last'] = ($i % 2 != 0) ? true : false;  
          }else{
            $args['is_last'] = ($i % 2 == 0) ? true : false;
          }
          
          $args['is_end']  = ( $i == $j - 1 ) ? true : false;

                 $featured_story = new Control_long_pic_story( $featured_layout->posts_stack[$i], (int)$category_id, false, false, true );
                 $featured_story->display($args);
        }

        ?>
<div class="group">
<div style="width: 728px; margin:0 auto;">
<?php dynamic_sidebar( 'leaderboard-btf1' ); ?>
</div>
</div>
<div class="life-style clearfix group"><?php get_group( 'life-style' ); ?></div>


<div class="pakistan clearfix group"><?php get_group( 'pakistan' ); ?></div>
<div class="group">
<div style="width: 728px; margin:0 auto;">
<?php dynamic_sidebar( 'leaderboard-btf2' ); ?>
</div>
</div>
<div class="opinion clearfix group"><?php get_group( 'opinion' ); ?></div>

<div class="sports clearfix group"><?php get_group( 'sports' ); ?></div>
<div class="group">
<div style="width: 728px; margin:0 auto;">
<?php dynamic_sidebar( 'leaderboard-btf3' ); ?>
</div>
</div>
<div class="business clearfix group"><?php get_group( 'business' ); ?></div>

<div class="videos group"><?php get_group( 'videos', array( 'num_videos' => 11 ) ); ?></div>
  
<div class="world clearfix group"><?php get_group( 'world' ); ?></div>
	</div>

<div class="col-lg-4">



 
<?php get_sidebar(); ?>

		</div>	
</div>


<div class="slideshows span-24 group"><?php get_group( 'slideshows', array( 'num_slideshows' => 18 ) ); ?></div>
</div>
<?php get_footer(); ?>
