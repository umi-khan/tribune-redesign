<div id="trend_more_pager_anchor" class="clearfix">
	<a id="trending_more_pager" class="offset-<?php echo $next_offset; ?> slug-<?php echo $trend_slug; ?>" href="#">more</a>
</div>
<img id="trending_spinner" src="<?php echo ET_PLUGIN_URL . 'images/spinner.gif'; ?>" alt="" />