-- Upgrade Script --
Author	:	Umair Jabbar
Contact	:	umair.jabbar@tribune.com.pk

The script in this folder can be used to migrate from old layout manager to new layout management plugin. It simply migrates older records to new layout management's DB