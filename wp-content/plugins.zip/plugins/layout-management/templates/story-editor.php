<div id="lm_story_editor" class="lm_story_editor">
	<div id="lm_story_editor_message" class="clear"><p></p></div>
	<h4 class="lm_story_editor_heading">Edit Story</h4>

	<p>
		<label for="lm_story_editor_title">Title</label>
		<input type="text" class="text" id="lm_story_editor_title" value="" />
	</p>

	<p>
		<label for="lm_story_editor_excerpt">
			Excerpt <span class="lm_excerpt_chars_counter">Characters remaining: <span></span></span>
		</label>
		<span class="lm_excerpt_error_content"></span>
		<textarea id="lm_story_editor_excerpt" class="text"></textarea>
	</p>

	<p class="lm_story_editor_submit">
		<input id="lm_story_editor_cancel_button" class="submit" type="button" name="cancel_btn" value="Cancel" />
		<input id="lm_story_editor_submit_button" class="submit" type="button" name="submit_btn" value="Save Changes" />
	</p>
</div>