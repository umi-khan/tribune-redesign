<div class="lm_story clearfix" id="storyid-<?php echo $category_id . '_' . $story->id; ?>">
	<div class="lm_story_title left"><?php echo esc_html( $story->title ); ?></div>
	<div class="lm_story_excerpt display-none"><?php echo esc_html( $story->excerpt ); ?></div>
	<div class="lm_story_links right">
		<a class="lm_story_set_link" href="#">set</a> |
		<a class="lm_story_edit_link" href="#">quick edit</a> |
		<a href="<?php echo $story->permalink; ?>" target="_blank">view</a> |
		<a href="<?php echo admin_url( 'post.php?action=edit&post='.$story->id ); ?>" target="_blank">edit</a>
	</div>
</div>