<div class="vm_add_video">

	<h3>Add Youtube, Dailymotion, Facebook, JWPlatform Or Vimeo by copying the video's url and pasting it below:</h3>

	<div id="vm_add_video_msg"><p></p></div>
	
	<p>
		<input type="text" class="text" id="vm_url" name="vm_url" size="82" />

		<input type="button" value="Add" class="button" id="vm_add_btn" />
		<img alt="loading" id="vm_loading_img" src="<?php echo admin_url('images/wpspin_light.gif'); ?>" />
	</p>

</div>
