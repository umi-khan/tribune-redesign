	<div class="more-story">
 		<h4 class="top-news"><?php echo $widget_title;?></h4>
		<?php
			$counter = 0;
			$posts_count = count( $posts );
			if ($posts_count > 0 ){
			foreach( $posts as $post ) :
				$media = $post['media'];
				$author = $post['author'];

				?>
				<?php if ($counter ==0){ ?>
		<div class="span-8 story long-story" style="margin-top:10px; width:100%;">
			<a class="image" href="<?php echo $post['url']; ?>"> 
				<div style="width:100%; height:180px; overflow:hidden;">
					<img src="<?php echo str_replace( 'http://', 'http://i0.wp.com/', $media['large_url'] ) . '?w=305'; ?>" width="100%" height="auto" title="<?php echo $media['caption'];?>" alt="<?php echo $media['caption'];?>" >
				</div>
			</a>
			<h2 class="title" style="font-size:20px;"><a class="title" href="<?php echo $post['url'];?>" title="<?php echo $post['title'];?>"><?php echo $post['title'];?></a></h2>
			<div class="meta">
				<span class="author"><?php echo $author['name'];?></span>
			</div>
		</div>
	<div class="span-8 last" style="border-bottom:1px dotted #d2d0c2; margin: 10px 0 20px;" ></div>

	<?php }else{ ?>

	<div class="story small-story<?php echo ($counter == $posts_count - 1)? " last":"";?>">
		<div class="content clearfix">
			<a href="<?php echo $post['url']; ?>" class="image">
				<img width="125" height="94" alt="<?php echo $media['caption'];?>" title="<?php echo $media['caption'];?>" src="<?php echo $media['thumb_url'];?>">
			</a>
			<h2 class="title" style="font-size:15px;">
				<a title="<?php echo $post['title'];?>" href="<?php echo $post['url'];?>"><?php echo $post['title'];?></a>
			</h2>
			<div class="meta">
				<span class="author"><?php echo $author['name'];?></span>
			</div>
		</div>

	</div>
	<?php } ?>
	<?php 
	$counter++;
	endforeach;
	} ?>
</div>
 <div class="clear"></div>
